<footer class="main-footer" style="padding-bottom:35px">
  <div class="col-xs-12 text-right" > </div>
</footer>
<?php /**PATH /home/yousry/Desktop/erp/codecanyon-sKs34iSc-laravel-ecommerce-universal-ecommercestore-full-website-with-themes-and-advanced-cmsadmin-panel/main_web_new/source code/adminpanel/resources/views/admin/common/footer.blade.php ENDPATH**/ ?>