<!-- Banners Content -->
<section class="banners-content">

  <?php  echo $final_theme['banner']; ?>

</section>
<?php /**PATH /home/yousry/Desktop/erp/codecanyon-sKs34iSc-laravel-ecommerce-universal-ecommercestore-full-website-with-themes-and-advanced-cmsadmin-panel/main_web_new/source code/adminpanel/resources/views/web/product-sections/banner_section.blade.php ENDPATH**/ ?>