<!-- //banner one -->
<div class="banner-one">
    <div class="container">
      <div class="group-banners">
          <div class="row">
            <?php if(count($result['commonContent']['homeBanners'])>0): ?>
             <?php $__currentLoopData = ($result['commonContent']['homeBanners']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $homeBanners): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($homeBanners->type==3 or $homeBanners->type==4 or $homeBanners->type==5): ?>
                <div class="col-12 col-md-4">
                  <figure class="banner-image ">
                    <a href="<?php echo e($homeBanners->banners_url); ?>"><img class="img-fluid" src="<?php echo e(asset('').$homeBanners->path); ?>" alt="Banner Image"></a>
                  </figure>
                </div>
              <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </div>
        </div>
    </div>
</div>


<?php /**PATH /home/yousry/Desktop/erp/codecanyon-sKs34iSc-laravel-ecommerce-universal-ecommercestore-full-website-with-themes-and-advanced-cmsadmin-panel/main_web_new/source code/adminpanel/resources/views/web/banners/banner1.blade.php ENDPATH**/ ?>